function onEvent(name, value1, value2)
    if name == 'Fake FC' then
        setProperty('cpuControlled', true)
    end
end