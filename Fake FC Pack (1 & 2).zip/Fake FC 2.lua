function onEvent(name, value1, value2)
    if name == 'Fake FC 2' then
        addScore('350')
        setRatingPercent(value1)
    if ratingName == '?' then
        setRatingName('Perfect!!!')
    end
end
end