--Explained thouroughly because of how little I knew when I started Psych LUA
function onEvent(name, value1, value2)
    if name == 'Remove Enemy Lyric' then
        removeLuaText('text2');--Text won't be removed without this
    end
end