--Explained thouroughly because of how little I knew when I started Psych LUA
function onEvent(name, value1, value2)
    if name == 'Remove Player Lyric' then
        removeLuaText('text1');--Text won't be removed without this
    end
end